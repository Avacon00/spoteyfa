# SPOTEYFA v0.3.0 - Windows Final

## Installation

Doppelklick: INSTALLATION.bat

Dann waehlen:
1. Super-Installer (robust)
2. Portable Node.js (garantiert)

## Ihr Problem geloest

"Installation eventuell nicht komplett"
-> Option 2 verwenden

"Node.js nicht installiert" 
-> Option 2 verwenden

Option 2 funktioniert IMMER!
